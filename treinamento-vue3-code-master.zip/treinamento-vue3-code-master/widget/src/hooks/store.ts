import Store, { StoreState } from '../store'

export default function useStore (): StoreState {
  return Store
}
