export type RequestError = {
  status: number;
  statusText: string;
}
