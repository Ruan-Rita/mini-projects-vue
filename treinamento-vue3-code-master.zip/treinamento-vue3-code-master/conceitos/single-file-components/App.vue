<template>  
  <h1>Hello World</h1>
</template>

<script lang="ts">
export default {}
</script>

<style lang="scss">
</style>
